from django.apps import AppConfig


class HankkiConfig(AppConfig):
    name = 'hankki'
